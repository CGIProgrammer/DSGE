#ifndef SHADOWMAP_GLSL
#define SHADOWMAP_GLSL

float shadow_sample(sampler2D shadowmap, mat4 proj, vec3 n, vec3 p, vec3 l_norm, float fr_dist, float zfar, float znear)
{
    vec4 shadowmap_homogeneous = proj * vec4(p, 1.0);
    vec2 shadowmap_2d_coord = shadowmap_homogeneous.xy;
    float shadow = 1.0;
    float sm_dist = 0.0;
    if (shadowmap_homogeneous.w > 0.0) {
        shadowmap_2d_coord = (shadowmap_2d_coord / shadowmap_homogeneous.w) * 0.5 + 0.5;
        sm_dist = linearize_depth(texture(shadowmap, shadowmap_2d_coord).r, znear, zfar);
        float bias = max(0.05 * (1.0 - dot(n, l_norm)), 0.1);
        shadow = float(fr_dist < sm_dist.r + bias);
    }
    return shadow;
}

float shadow_sample(samplerCube shadowmap, vec3 n, vec3 p, vec3 l_norm, float fr_dist, float zfar, float znear)
{
    float shadow = 1.0;
    float sm_dist = 0.0;
    sm_dist = linearize_depth(texture(shadowmap, l_norm).r, znear, zfar);
    float bias = max(0.05 * (1.0 - dot(n, l_norm)), 0.1);
    shadow = float(fr_dist < sm_dist.r + bias);
    return shadow;
}

#endif