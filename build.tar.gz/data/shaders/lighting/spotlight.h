#ifndef SPOTLIGHT_GLSL
#define SPOTLIGHT_GLSL

vec3 spotlight(SpotLight light, vec3 n, vec3 p)
{
    vec3 l = p - light.location;
    float dist = length(l);
    vec3 ln = l / dist;
    vec3 intensity = light.color * light.power;
    float att = pow(dist+1.0, -2.0);
    float cos_a = dot(ln, light.direction);
    float spot_limit = smoothstep(cos(light.angle), cos(light.inner_angle), cos_a);
    if (light.shadowmap_index > -1) {
        float shadow = shadow_sample(spot_shadowmaps[light.shadowmap_index], light.projection_inv, n, p, ln, dist, light.zfar, light.znear);
        return intensity * att * shadow * max(dot(ln, -n), 0.0) * spot_limit;
    } else {
        return intensity * att * max(dot(ln, -n), 0.0) * spot_limit;
    }
}

#endif