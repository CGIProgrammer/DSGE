void main()
{
    float nLength = length(v_nor);
    mat4 model = camera.transform_inverted * transform;
    TBN = mat3(v_tan, normalize(cross(v_nor, v_tan)), v_nor);
    TBN = mat3(transform[0].xyz, transform[1].xyz, transform[2].xyz) * TBN;
    position = camera.projection * model * vec4(v_pos, 1.0);
    position_prev = camera.projection * camera.transform_prev_inverted * transform_prev * vec4(v_pos, 1.0);
    world_position = (model * vec4(v_pos, 1.0)).xyz;
    texture_uv = vec2(v_tex1.x, 1.0-v_tex1.y);
    view_vector = (camera.transform_inverted * position).xyz;
    gl_Position = position;
}