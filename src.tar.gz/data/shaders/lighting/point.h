#ifndef POINT_LIGHT_GLSL
#define POINT_LIGHT_GLSL

vec3 point_light(PointLight light, vec3 n, vec3 p)
{
    vec3 l = p - light.location;
    float dist = length(l);
    vec3 ln = l / dist;
    vec3 intensity = light.color * light.power;
    float att = pow(dist+0.1, -2.0);
    if (light.shadowmap_index > -1) {
        float shadow = shadow_sample(
            point_shadowmaps[light.shadowmap_index], n, p, ln, dist, light.zfar, light.znear);
        return intensity * att * shadow * max(dot(ln, -n), 0.0);
    } else {
        return intensity * att * max(dot(ln, -n), 0.0);
    }
}

#endif