//layout (origin_upper_left) in vec4 gl_FragCoord;
#include "depth_packing.h"
#include "debug_gui.h"
#include "lighting/shadowmap.h"
#include "lighting/point.h"
#include "lighting/spotlight.h"
#include "constants.h"


void main()
{
    //vec2 fragCoord = gl_FragCoord.xy / textureSize(gAlbedo, 0).xy * vec2(1.0, -1.0) + vec2(0.0, 1.0);
    vec2 camera_zrange = depth_range(camera.projection);
    ivec2 pixelCoord = ivec2(pixelCoord);
    swapchain_out = vec4(fragCoord, 0.0, 1.0);
    //return;
    ivec2 ts = textureSize(font, font_mip);
    char_size = ts / 16;
    debug_gui_resolution = ivec2(textureSize(gAlbedo, 0).xy);
    
    float linear_depth = linearize_depth(texelFetch(gDepth, pixelCoord, 0).r, camera_zrange.x, camera_zrange.y);
    if (texelFetch(gDepth, pixelCoord, 0).r==1.0) {
        linear_depth = 1e14;
    }
    
    /*vec2 zrange = depth_range(light.projection);
    float znear = zrange.x;
    float zfar = zrange.y;*/
    float debug_depth = linearize_depth(texture(gDepth, vec2(0.5)).r, camera_zrange.x, camera_zrange.y);
    SpotLight unpacked_light = unpack_spotlight(lights_data, 0);
    int first_point_light = lights_count.spotlights;
    PointLight unpacked_point_light = unpack_point_light(lights_data, first_point_light);
    /*SpotLight unpacked_light;
    unpacked_light.location = testing_light.location_znear.xyz;
    unpacked_light.direction = testing_light.direction_zfar.xyz;
    unpacked_light.color = testing_light.color.rgb;
    unpacked_light.power = testing_light.color.w;
    unpacked_light.distance = testing_light.direction_zfar.w;
    unpacked_light.znear = testing_light.location_znear.w;
    unpacked_light.angle = testing_light.angle;
    unpacked_light.inner_angle = testing_light.inner_angle;
    unpacked_light.shadow_buffer = testing_light.shadow_buffer != 0;
    unpacked_light.projection_inv = testing_light.projection_inv;
    unpacked_light.shadowmap_index = testing_light.shadowmap_index;*/

    vec3 albedo = pow(texelFetch(gAlbedo, pixelCoord, 0).rgb, vec3(1.0/GAMMA));
    vec3 normals = normalize(texelFetch(gNormals, pixelCoord, 0).rgb);
    vec3 position = gPosition(linear_depth, fragCoord, camera.projection_inverted, camera.transform).xyz;
    vec3 ambient_light = vec3(0.01);
    vec3 lighting = ambient_light;
    for (int i=0; i<lights_count.spotlights; i++) {
        SpotLight light = unpack_spotlight(lights_data, i);
        lighting += spotlight(light, normals, position);
    }
    for (int i=lights_count.spotlights; i<lights_count.spotlights+lights_count.point_lights; i++) {
        PointLight light = unpack_point_light(lights_data, i);
        lighting += point_light(light, normals, position);
    }
    swapchain_out.rgb = albedo * lighting;
    swapchain_out.rgb = max(swapchain_out.rgb, 0.0);

    swapchain_out.rgb = swapchain_out.rgb / (1.0 + swapchain_out.rgb);
    //draw_cross(swapchain_out, vec3(1.0));
    
    // Глубина центральной точки
    //swapchain_out.rgb = mix(swapchain_out.rgb, vec3(0.0, 0.5, 0.0), draw_float(debug_depth, debug_gui_resolution/2 + ivec2(2, 6), 3));
    // Направление прожектора из uniform-переменной
    /*swapchain_out.rgb = mix(swapchain_out.rgb, vec3(1.0, 1.0, 0.5),
        + print(abs(unpacked_point_light.location), ivec2(0, char_size.y))
    );*/
    
    swapchain_out.a = 1.0;
}