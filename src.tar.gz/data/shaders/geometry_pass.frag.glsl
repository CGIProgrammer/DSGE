/*#ifndef CONTEXT

#endif*/
#include "constants.h"

void main()
{
    mat3 tbn = TBN;
    tbn[0] = normalize(tbn[0]);
    tbn[1] = normalize(tbn[1]);
    tbn[2] = normalize(tbn[2]);
    mNormal = tbn[2];
    //tbn = transpose(tbn);
    principled();
    mDiffuse.rgb = pow(mDiffuse.rgb, vec3(GAMMA));
    if (mDiffuse.a < 0.5)
    {
        mDiffuse.a = 1.0;
        //discard;
    }
    vec2 velocity_vector = (position.xy/position.w*0.5+0.5) - (position_prev.xy/position_prev.w*0.5+0.5);
    gAlbedo.rgb = mDiffuse.rgb;
    gAlbedo.a = 1.0;
    gNormals = vec3(mNormal);
    gMasks = vec3(mSpecular, mRoughness, mMetallic);
    gVectors = vec4(velocity_vector, 0.0, 1.0);
}