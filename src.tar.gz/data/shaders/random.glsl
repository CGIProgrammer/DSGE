#ifndef RANDOM_H
#define RANDOM_H

#define TILE_SIZE 64
#define NOISE_TEXTURE_SIZE 1024
#define TILE_DIM (NOISE_TEXTURE_SIZE/TILE_SIZE)
#define TILES_COUNT (TILE_DIM*TILE_DIM)

// Функция blue_rand возвращает сэмл синего шума для текущих координат
// Работатет только с текстурой шума 1024x1024
vec4 blue_rand(sampler2D noise_texture, int seed)
{
    ivec2 crd = ivec2(mod(gl_FragCoord.xy, vec2(TILE_SIZE)));
    seed = min(seed, TILES_COUNT);
    int seed_x = int(mod(seed, TILE_DIM));
    int seed_y = seed/TILE_DIM;
    return texelFetch(noise_texture, crd + ivec2(seed_x, seed_y) * TILE_SIZE, 0);
}

#endif